-- Adminer 4.1.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DELIMITER ;;

DROP PROCEDURE IF EXISTS `get_core_parameters`;;
CREATE PROCEDURE `get_core_parameters`(IN `is_proc_name` varchar(128), IN `is_db_name` varchar(64))
BEGIN
  SELECT
    a.param_list,
    a.db
  FROM mysql.proc a
  WHERE a.name = is_proc_name COLLATE utf8_czech_ci
  AND a.db = is_db_name COLLATE utf8_czech_ci
  LIMIT
  1;
END;;

DROP PROCEDURE IF EXISTS `get_meeting`;;
CREATE DEFINER=`usr5_sasap`@`localhost` PROCEDURE `get_meeting`(IN `inl_id_meeting` int(11) unsigned)
BEGIN

SELECT *
FROM meeting
WHERE id_meeting = inl_id_meeting
;

END;;

DROP PROCEDURE IF EXISTS `get_meeting_list`;;
CREATE DEFINER=`usr5_sasap`@`localhost` PROCEDURE `get_meeting_list`()
BEGIN

SELECT *
FROM meeting;

END;;

DROP PROCEDURE IF EXISTS `get_person`;;
CREATE DEFINER=`usr5_sasap`@`localhost` PROCEDURE `get_person`(IN `inl_id_person` int(11) unsigned)
SELECT *
FROM person
WHERE id_person = inl_id_person;;

DROP PROCEDURE IF EXISTS `get_person_classmate`;;
CREATE DEFINER=`usr5_sasap`@`localhost` PROCEDURE `get_person_classmate`(IN `inl_id_person` tinyint)
BEGIN

/* Spoluzaci z krouzku */
SELECT hgp.id_person,
       CONCAT(p.s_name, ' ', p.s_lastname) AS s_classmate_name,
       GROUP_CONCAT(hgp.id_hobby_group) AS id_hobby_group,
       GROUP_CONCAT(hg.s_name) AS s_hobby_group_name

FROM hobby_group_person hgp

LEFT JOIN hobby_group hg
ON hg.id_hobby_group = hgp.id_hobby_group

LEFT JOIN person p
ON p.id_person = hgp.id_person

WHERE hgp.id_person IN (
	SELECT hgp.id_hobby_group
	FROM hobby_group_person hgp
	WHERE hgp.id_person = inl_id_person

) AND NOT hgp.id_person = inl_id_person

GROUP BY p.id_person;

END;;

DROP PROCEDURE IF EXISTS `get_person_details`;;
CREATE DEFINER=`usr5_sasap`@`localhost` PROCEDURE `get_person_details`(
  IN `inl_id_person` int(11) unsigned
)
BEGIN

  /* Seznam ID vsech zajmu dane osoby */
  CREATE TEMPORARY TABLE hobby ENGINE=MEMORY AS (
    SELECT hgp.id_hobby_group
    FROM hobby_group_person hgp
    WHERE hgp.id_person = inl_id_person
  );
  
  SELECT p.*
  FROM person p
  WHERE p.id_person = inl_id_person;
  
  /* Detaily zajmu dane osoby */
  SELECT hg.*
  FROM hobby h
  LEFT JOIN hobby_group hg
  ON hg.id_hobby_group = h.id_hobby_group;
  
  /* Spoluzaci z krouzku */
  SELECT hgp.id_person,
         hgp.id_hobby_group,
         hg.s_name
  FROM hobby_group_person hgp
  LEFT JOIN hobby_group hg
  ON hg.id_hobby_group = hgp.id_hobby_group
  WHERE hgp.id_person IN (SELECT * FROM hobby) AND NOT hgp.id_person = inl_id_person;

END;;

DROP PROCEDURE IF EXISTS `get_person_list`;;
CREATE DEFINER=`usr5_sasap`@`localhost` PROCEDURE `get_person_list`()
BEGIN

SELECT p.*,
       GROUP_CONCAT(hg.s_name) AS hobby_group_name

FROM person p

LEFT JOIN hobby_group_person hgp
ON hgp.id_person = p.id_person

LEFT JOIN hobby_group hg
ON hgp.id_hobby_group = hg.id_hobby_group

GROUP BY p.id_person;

END;;

DROP PROCEDURE IF EXISTS `get_person_meeting_group_list`;;
CREATE DEFINER=`usr5_sasap`@`localhost` PROCEDURE `get_person_meeting_group_list`(
  IN `inl_id_meeting` int(11) unsigned,
  IN `inl_id_meeting_group` int(11) unsigned
)
BEGIN

SELECT p.*,
       GROUP_CONCAT(hg.s_name) AS hobby_group_name

FROM person p

LEFT JOIN person_meeting pc
ON pc.id_person = p.id_person

LEFT JOIN hobby_group_person hgp
ON hgp.id_person = p.id_person

LEFT JOIN hobby_group hg
ON hgp.id_hobby_group = hg.id_hobby_group

WHERE pc.id_meeting = inl_id_meeting AND
pc.id_meeting_group = inl_id_meeting_group

GROUP BY p.id_person;

END;;

DROP PROCEDURE IF EXISTS `store_meeting_person`;;
CREATE PROCEDURE `store_meeting_person`(IN `nl_id_person` tinyint, IN `s_name` varchar(128), IN `s_phone` varchar(32), IN `s_email` varchar(64), IN `s_note` text)
BEGIN



END;;

DELIMITER ;

DROP TABLE IF EXISTS `hobby_group`;
CREATE TABLE `hobby_group` (
  `id_hobby_group` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Číslo zájmového kroužku',
  `s_name` varchar(100) NOT NULL COMMENT 'Název zájmového kroužku',
  `s_glyphicon` varchar(100) NOT NULL COMMENT 'Ikona Bootstrap',
  PRIMARY KEY (`id_hobby_group`),
  UNIQUE KEY `id_hobby_group` (`id_hobby_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Zájmy';

INSERT INTO `hobby_group` (`id_hobby_group`, `s_name`, `s_glyphicon`) VALUES
(1,	'Příroda',	'glyphicon-tree-deciduous'),
(2,	'Kreslení',	'glyphicon-pencil'),
(3,	'Turistika',	'glyphicon-picture'),
(4,	'Fotografování',	'glyphicon-camera');

DROP TABLE IF EXISTS `hobby_group_person`;
CREATE TABLE `hobby_group_person` (
  `id_hobby_group` int(11) unsigned NOT NULL COMMENT 'Číslo zájmového kroužku',
  `id_person` int(11) unsigned NOT NULL COMMENT 'Číslo osoby',
  KEY `id_hobby_group` (`id_hobby_group`),
  KEY `id_person` (`id_person`),
  CONSTRAINT `hobby_group_person_ibfk_3` FOREIGN KEY (`id_hobby_group`) REFERENCES `hobby_group` (`id_hobby_group`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `hobby_group_person_ibfk_4` FOREIGN KEY (`id_person`) REFERENCES `person` (`id_person`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Osoby vs zájmy';

INSERT INTO `hobby_group_person` (`id_hobby_group`, `id_person`) VALUES
(1,	1),
(2,	3),
(2,	2),
(3,	3),
(3,	2),
(4,	3),
(3,	4),
(2,	1),
(4,	1);

DROP TABLE IF EXISTS `meeting`;
CREATE TABLE `meeting` (
  `id_meeting` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Číslo setkání',
  `s_name` varchar(100) NOT NULL COMMENT 'Název setkání',
  `s_detail` text NOT NULL COMMENT 'Popis akce',
  `s_people_max` smallint(3) unsigned NOT NULL COMMENT 'Max.počet osob',
  `dt_when` datetime DEFAULT NULL COMMENT 'Datum a čas akce',
  `dt_created` datetime DEFAULT NULL COMMENT 'Datum vytvoření',
  PRIMARY KEY (`id_meeting`),
  UNIQUE KEY `id_preschool` (`id_meeting`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Setkání';

INSERT INTO `meeting` (`id_meeting`, `s_name`, `s_detail`, `s_people_max`, `dt_when`, `dt_created`) VALUES
(1,	'Neděle s Jógou duben 2016',	'V případě, že určitě přijdete, zapište se do tabulky Účastníci. Pokud jste se zapsali a zjistíte, že nemůžete přijít, hned se vymažte! Náhradníci se tak mohou dostat mezi účastníky.',	12,	'2016-04-22 11:00:00',	'2016-03-22 01:47:42'),
(2,	'Neděle s Jógou březen 2016',	'V případě, že určitě přijdete, zapište se do tabulky Účastníci. Pokud jste se zapsali a zjistíte, že nemůžete přijít, hned se vymažte! Náhradníci se tak mohou dostat mezi účastníky.',	0,	'2016-03-22 11:00:00',	'2016-03-22 01:47:59');

DROP TABLE IF EXISTS `meeting_group`;
CREATE TABLE `meeting_group` (
  `id_meeting_group` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID skupiny v rámci kurzu',
  `s_name` varchar(100) NOT NULL COMMENT 'Název skupiny',
  PRIMARY KEY (`id_meeting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Setkání vs skupiny osob';

INSERT INTO `meeting_group` (`id_meeting_group`, `s_name`) VALUES
(1,	'Potvrzení účastníci'),
(2,	'Náhradníci');

DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `id_person` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Číslo osoby',
  `s_name` varchar(100) NOT NULL COMMENT 'Jméno',
  `e_gender` enum('Neuvedeno','Muž','Žena') NOT NULL COMMENT 'Pohlaví',
  `nl_age` tinyint(3) unsigned NOT NULL COMMENT 'Věk',
  `s_phone` varchar(50) DEFAULT NULL COMMENT 'Telefon',
  `s_email` varchar(50) DEFAULT NULL COMMENT 'E-mail',
  `s_note` varchar(255) DEFAULT NULL COMMENT 'Poznámka',
  PRIMARY KEY (`id_person`),
  UNIQUE KEY `id_person` (`id_person`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Osoby';

INSERT INTO `person` (`id_person`, `s_name`, `e_gender`, `nl_age`, `s_phone`, `s_email`, `s_note`) VALUES
(1,	'Magda Hrušková',	'Žena',	8,	'12345',	'test@test.cz',	NULL),
(2,	'Maruška Vavřínová',	'Žena',	9,	'',	'',	NULL),
(3,	'Jiří Lebeda',	'Muž',	10,	'',	'',	NULL),
(4,	'Váňa Ivanov',	'Muž',	8,	'',	'',	NULL),
(5,	'Vendula Kubová',	'Žena',	11,	'',	'',	NULL);

DROP TABLE IF EXISTS `person_meeting`;
CREATE TABLE `person_meeting` (
  `id_person` int(11) unsigned NOT NULL COMMENT 'Číslo osoby',
  `id_meeting` int(11) unsigned NOT NULL COMMENT 'Číslo kurzu',
  `id_meeting_group` int(11) unsigned NOT NULL COMMENT 'Číslo skupiny v rámci kurzu',
  KEY `id_person` (`id_person`),
  KEY `id_preschool` (`id_meeting`),
  KEY `id_meeting_group` (`id_meeting_group`),
  CONSTRAINT `person_meeting_ibfk_3` FOREIGN KEY (`id_meeting_group`) REFERENCES `meeting_group` (`id_meeting_group`),
  CONSTRAINT `person_meeting_ibfk_1` FOREIGN KEY (`id_meeting`) REFERENCES `meeting` (`id_meeting`),
  CONSTRAINT `person_meeting_ibfk_2` FOREIGN KEY (`id_person`) REFERENCES `person` (`id_person`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Setkání vs osoby';

INSERT INTO `person_meeting` (`id_person`, `id_meeting`, `id_meeting_group`) VALUES
(3,	1,	1),
(2,	1,	1),
(1,	1,	2);

-- 2016-03-23 00:40:01
